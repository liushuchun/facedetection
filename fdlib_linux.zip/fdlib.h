void fdlib_detectfaces(unsigned char *rgbimage, int imagewidth, int imageheight, int threshold);
int fdlib_getndetections();
void fdlib_getdetection(int nr, int *xpos, int *ypos, int *width);

